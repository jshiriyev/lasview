import lasio

from .layout._label import Label
from .layout._depth import Depth
from .layout._xaxis import Xaxis

from .layout._layout import Layout

from .layout._datum import Datum

class Wizard(Layout):

	def __init__(self,lasfile:lasio.LASFile,**kwargs):

		super().__init__(**kwargs)

		self._lasfile = lasfile

	@property
	def lasfile(self):
		return self._lasfile

	@property
	def depth(self):
		return self._depth
	
	@depth.setter
	def depth(self,value:dict):

		if kwargs.get("limit") is None:
			kwargs["limit"] = Datum(self.lasfile[0]).limit

		self._depth = Depth(**value)

if __name__ == "__main__":

	layout = Layout(trails=5,curves=3,width=(2,),label_loc="top")

	print(layout.width)

	print(layout.head.curves)
	print(layout.head.height)
	print(layout.body.height)