class Perfor():

	def __init__(self,limit):

		self._limit = limit

	@property
	def limit(self):
		return self._limit