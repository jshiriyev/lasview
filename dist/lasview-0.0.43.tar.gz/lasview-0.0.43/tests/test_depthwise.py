import unittest

import numpy as np

from pphys import DepthView

class TestDepthView(unittest.TestCase):

    def test_get_xticks(self):
        pass

    def test_get_yticks(self):
        
        root = tk.Tk()

        # las = DepthView(root)

        # yticks = las.get_yticks(top=5,bottom=30)

        # yticks_true = np.array([0.,10,20,30,40])

        # np.testing.assert_array_equal(yticks,yticks_true)
                       
if __name__ == "__main__":

    unittest.main()
