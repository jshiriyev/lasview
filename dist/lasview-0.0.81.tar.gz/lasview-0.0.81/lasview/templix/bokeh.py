sandstone = dict(
    fill_color = "yellow",
    hatch_color = "black",
    hatch_alpha = 0.3,
    hatch_scale = 4,
    hatch_pattern = '.'
    )